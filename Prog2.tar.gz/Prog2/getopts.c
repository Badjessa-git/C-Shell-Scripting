/*
  CSE 109
  Badjessa Bahoumda
  bbb219
  Program Description: This program will take the command and return
  an array of the different token of the command
  Program #2
*/

#include <string.h>
#include <stdlib.h>


char ** getopts(char cmd[]){
  char cmd1[500];
  char cmd2[500];
  char **cmd3;
  int count =0;
  int count2 =0;
  
  strcpy(cmd1,cmd);
  strcpy(cmd2,cmd);
  char *token = strtok(cmd1, " ");

  while (token != NULL) {
    count++;
    token =  strtok(NULL," " );
  }

 cmd3 =  malloc((count + 1) * sizeof(char*));
 token = strtok(cmd2, " ");
   while (token != NULL) {
    cmd3[count2] = malloc(strlen(token));
    strcpy(cmd3[count2], token);
    count2++;
    token =  strtok(NULL, " ");
  }
   cmd3[count2+1]= 0;
   return cmd3;

  
}

