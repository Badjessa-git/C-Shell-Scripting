#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

/*
  CSE 109
  Badjessa Bahoumda
  bbb219
  Program Description: This program is the face of a shell that
  prompts the user of command inputs and react accordingly 
  Program #2
*/

char ** getopts(char cmd[]);

int main(int argc, char  *argv[]) {
  char host[20];
  char cmd[20];
  char **newargv;

  while (1) {  
  gethostname(host, sizeof host);
  strcat(host, ">");
  printf("%s ", host);

  fgets(cmd, sizeof(cmd), stdin); 
  int len =  strlen(cmd);
  cmd[len-1] = '\0';
  
  if (strcmp(cmd, "exit") != 0) {
  newargv =  getopts(cmd);
    if (fork() == 0) {
    execvp(newargv[0], newargv);
  } else {
    wait(NULL);
  }
   
  }
  else {
    return 0;
  }
}
}
