#ifndef TRIE_H
#define TRIE_H

#include "Node.h"
#include "Link.h"
#include <iostream>
using namespace std;

class Trie {
public:
  Node* start; //pointer to the start node

  Trie(); //Constructor

  ~Trie(); //deconstructor

  
  void put(string key, int value); //adding new key and value to Trie
  int get(string key); //retrieve value from Trie using key
  
};

#endif
