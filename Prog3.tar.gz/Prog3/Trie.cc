#include <cstdlib>
#include <stdio.h>
#include <string>
#include "Trie.h"


Trie::Trie() {
  start = new Node();
}

Trie::~Trie() {}

void Trie::put(string key, int value){
  Node* curr;
  curr = start;
  int len = key.length();
  int i;
  int b = 0;
  for (i = 0; i < len; i++) {
  b = (int) key[i] - (int)'a';
  if (curr->links[b] == NULL){
    curr->links[b] = new Link(key[i]);
    curr->total_num++;
    }
  curr = (curr->links[b])->Next;
  }
  curr->setValue(value);

  return;
}

int Trie::get(string key) {
  
  Node* rcurr;
  rcurr = start;
  int len = key.length();
  int a, i;
  
  for (i = 0; i < len; i++) {
    a = (int) key[i] - (int)'a';
    if (rcurr->links[a] == NULL) {
      return -1;
    }
    else {
      rcurr = (rcurr->links[a])->Next;
    }
    
  }
  return rcurr->getValue();
}
