/*
  CSE 109
  Badjessa Bahoumda
  bbb219
  Program Description: Create a trie, add word and get their int value
  Program #3
*/

#include <string>
#include "Trie.h"

using namespace std;

int main() {
  Trie* t;
  t = new Trie();
  t->put("lehigh", 1);
  t->put("lemon", 2);
  t->put("romeo", 3);

  cout << t->get("lehigh") <<endl;
  cout << t->get("lemon") <<endl;
  cout << t->get("romeo") <<endl;
    return 0;
}
