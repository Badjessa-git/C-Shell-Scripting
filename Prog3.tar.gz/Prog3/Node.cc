#include <cstdlib>
#include <stdio.h>
#include "Node.h"

Node::Node(){
  node_value = 0;
  links = new Link* [26]; 
  total_num = 0;
}

Node::Node(int value) {
  node_value = value;
  links = new Link* [26];
  total_num = 0;
}

Node::~Node() {
  
}

void Node:: setValue(int a){
  node_value = a;
}

int Node:: getValue() {
  return node_value;
}
