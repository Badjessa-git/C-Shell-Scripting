#include <cstdlib>
#include <stdio.h>
#include "Link.h"
#include "Node.h" 
Link::Link() {}
Link::Link(char c) {
  var  = c;
  Next = new Node();
}

Link::~Link() {

}


