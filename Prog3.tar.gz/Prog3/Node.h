#ifndef NODE_H
#define NODE_H

#include <iostream>
#include "Link.h"
using namespace std;

class Node
{
public:
  int node_value; //the value of the node
  Link **links; //the total links
  int total_num; //the total number of links used

  Node();//constructor

  Node(int);
  ~Node();//deconstructor

  void setValue(int); //setting node value
  int getValue(); //get node value
  
  
};

#endif
