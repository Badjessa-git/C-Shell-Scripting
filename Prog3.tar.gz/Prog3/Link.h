#ifndef LINK_H
#define LINK_H
#include <iostream>

using namespace std;

class Node;

class Link
{
public:
  char var; //hold the variable that takes you to the next node
  Node* Next;
  
  Link(); //constructor
  Link(char c);
  ~Link(); //deconstructor

};

#endif
