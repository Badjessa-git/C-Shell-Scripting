#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/*
  CSE 109
  Badjessa Bahoumda
  bbb219
  Program Description: This program scrambles letters wihout touching
  the first and the last letter
  Program #1
*/

void scramble(char buff[]);

int main(int argc, char *argv[]) {
  char buff[100];

   while (fgets(buff, sizeof buff, stdin)){
   int len = strlen(buff);
   buff[len-1]= '\0';
   scramble(buff); 
  }
    return 0;
 
}

void scramble(char buff[]) {
  char *token = strtok(buff, " ");
  while (token != NULL) {
    int len = ( strlen(token)-1);
    const char *spc = ".,:;";
    char *spca;
    spca = strpbrk(token, spc);
    if (spca) {
      len--;
    }
    if (len > 3) {
    int i, rand_var;
      for (i = 1; i < len; i++) {
	rand_var = 1 +  rand() %(len -1);
	char temp = token[i];
	token[i] = token[rand_var];
	token[rand_var] = temp;
    
    }
    }
    printf("%s ", token);
    token = strtok(NULL, " ");
  }
  printf("\n");
  return;
}

